﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LD3.Exercises
{
    enum Gender
    {
        Male = 1,
        Female = 2,
    }
}
